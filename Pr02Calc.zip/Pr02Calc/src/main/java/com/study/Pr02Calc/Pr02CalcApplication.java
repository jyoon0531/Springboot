package com.study.Pr02Calc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Pr02CalcApplication {

	public static void main(String[] args) {
		SpringApplication.run(Pr02CalcApplication.class, args);
	}

}
