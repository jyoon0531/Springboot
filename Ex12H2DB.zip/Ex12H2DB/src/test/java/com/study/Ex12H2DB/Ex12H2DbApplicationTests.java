package com.study.Ex12H2DB;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ex12H2DbApplicationTests {

	@Test
	void contextLoads() {
	}

}
