package com.study.Ex12H2DB;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ex12H2DbApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ex12H2DbApplication.class, args);
	}

}
