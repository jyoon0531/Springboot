package com.study.Pr07LoginJoin;

import lombok.Data;

@Data
public class ReqDto {
    private String inputName;
}
