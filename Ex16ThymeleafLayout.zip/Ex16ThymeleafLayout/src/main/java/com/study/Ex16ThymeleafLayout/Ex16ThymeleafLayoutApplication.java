package com.study.Ex16ThymeleafLayout;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ex16ThymeleafLayoutApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ex16ThymeleafLayoutApplication.class, args);
	}

}
