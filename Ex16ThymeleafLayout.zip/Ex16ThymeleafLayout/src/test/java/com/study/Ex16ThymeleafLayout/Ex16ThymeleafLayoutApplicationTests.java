package com.study.Ex16ThymeleafLayout;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ex16ThymeleafLayoutApplicationTests {

	@Test
	void contextLoads() {
	}

}
