package com.study.Pr03VMAns;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Pr03VmAnsApplication {

	public static void main(String[] args) {
		SpringApplication.run(Pr03VmAnsApplication.class, args);
	}

}
