package com.study.Pr03VMAns;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Pr03VmAnsApplicationTests {

	@Test
	void contextLoads() {
	}

}
