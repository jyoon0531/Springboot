package com.study.Ex14RealDB;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ex14RealDbApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ex14RealDbApplication.class, args);
	}

}
