package com.study.Pr01Counter;

import lombok.Data;

@Data
public class ReqDto {
    private String count;
}
