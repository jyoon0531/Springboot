package com.study.Pr01Counter;

import lombok.Data;

@Data
public class ResDto {
    private String count;
}
