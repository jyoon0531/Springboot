package com.study.Ex22TDD;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ex22TddApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ex22TddApplication.class, args);
	}

}
