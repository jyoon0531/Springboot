package com.study.Ex22TDD;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ex22TddApplicationTests {

	@Test
	void contextLoads() {
	}

}
