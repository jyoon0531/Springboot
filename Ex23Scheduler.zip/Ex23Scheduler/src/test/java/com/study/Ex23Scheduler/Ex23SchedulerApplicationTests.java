package com.study.Ex23Scheduler;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ex23SchedulerApplicationTests {

	@Test
	void contextLoads() {
	}

}
