package com.study.Pr07LoginJoin;

import lombok.Data;

@Data
public class ResDto {
    private String message;
}
