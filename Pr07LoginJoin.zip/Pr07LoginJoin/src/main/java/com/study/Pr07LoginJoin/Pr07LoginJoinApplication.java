package com.study.Pr07LoginJoin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Pr07LoginJoinApplication {

	public static void main(String[] args) {
		SpringApplication.run(Pr07LoginJoinApplication.class, args);
	}

}
