package com.study.Ex11MessageInter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ex11MessageInterApplicationTests {

	@Test
	void contextLoads() {
	}

}
