package com.study.Pr02Calc;

import lombok.Data;

@Data
public class ReqDto {
    private String num1;
    private String num2;

}
