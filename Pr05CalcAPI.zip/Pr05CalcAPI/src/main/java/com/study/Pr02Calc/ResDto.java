package com.study.Pr02Calc;

import lombok.Data;

@Data
public class ResDto {
    private String status;
    private String result;
}
