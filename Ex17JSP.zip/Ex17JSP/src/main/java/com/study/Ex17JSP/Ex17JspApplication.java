package com.study.Ex17JSP;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ex17JspApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ex17JspApplication.class, args);
	}

}
