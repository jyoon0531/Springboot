package com.study.Ex17JSP;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ex17JspApplicationTests {

	@Test
	void contextLoads() {
	}

}
