package com.study.Ex10Devtools;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ex10DevtoolsApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ex10DevtoolsApplication.class, args);
	}

}
