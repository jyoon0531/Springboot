package com.study.Ex10Devtools;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ex10DevtoolsApplicationTests {

	@Test
	void contextLoads() {
	}

}
