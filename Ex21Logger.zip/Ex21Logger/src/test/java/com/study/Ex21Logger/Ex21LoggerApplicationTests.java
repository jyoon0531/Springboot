package com.study.Ex21Logger;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ex21LoggerApplicationTests {

	@Test
	void contextLoads() {
	}

}
